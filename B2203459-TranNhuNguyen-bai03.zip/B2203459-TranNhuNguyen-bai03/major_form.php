<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="major_add.php" method="post">
        Major <input type="text" name="name_major">
        <button type="submit">save</button>
    </form>

</body>
</html>