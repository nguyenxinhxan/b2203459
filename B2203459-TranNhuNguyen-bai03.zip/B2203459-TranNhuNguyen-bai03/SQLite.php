<?php
try {
    $myPDO = new PDO('sqlite:/home/username/path/filename');
    echo "Kết nối cơ sở dữ liệu SQLite thành công!";
} catch (PDOException $e) {
    echo "Kết nối cơ sở dữ liệu SQLite thất bại: " . $e->getMessage();
}
?>
