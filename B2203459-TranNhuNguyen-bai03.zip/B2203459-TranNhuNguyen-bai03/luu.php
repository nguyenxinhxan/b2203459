<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";

// Tạo kết nối
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Kiểm tra dữ liệu đầu vào tránh lỗi SQL Injection
$name = $conn->real_escape_string($_POST["name"]);
$email = $conn->real_escape_string($_POST["email"]);
$major_id = $conn->real_escape_string($_POST["major_id"]);
// Xử lý ngày tháng
$date = date_create($_POST["birth"]);
$formatted_date = $date ? $date->format('Y-m-d') : null;

$sql = "INSERT INTO student (fullname, email, birthday, major_id) VALUES ('$name', '$email', '$formatted_date', '$major_id')";

if ($conn->query($sql) === TRUE) {
    echo "Thêm sinh viên thành công";
    // Chuyển hướng sau khi thêm thành công
    header('Location: taidulieu_bang1.php');
    exit(); // Dừng script sau khi chuyển hướng
} else {
    echo "Lỗi: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
